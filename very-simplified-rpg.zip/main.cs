using System;
using System.Threading;

namespace ConsoleApp17
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Witaj w mojej grze roguelike!");
            Console.WriteLine("Podaj wysokość planszy");
            int height = int.Parse(Console.ReadLine());
            Console.WriteLine("Podaj szerokość planszy");
            int width = int.Parse(Console.ReadLine());
            Console.Clear();

            string[,] plansza = new string[height, width];


            for (int i = 0; i < plansza.GetLength(0); i++)
            {
                for (int j = 0; j < plansza.GetLength(1); j++)
                {
                    plansza[i, j] = "x";
                }

            }

            string player = "P";
            int x = 1;
            int y = 1;
            plansza[x, y] = player;
            for (int i = 0; i < plansza.GetLength(0); i++)
            {
                for (int j = 0; j < plansza.GetLength(1); j++)
                {
                    Console.Write(plansza[i, j]);
                }
                Console.WriteLine("");
            }

            while (true)
            {
                ConsoleKeyInfo klawisz = Console.ReadKey(true);
                if (klawisz.Key == ConsoleKey.W)
                {
                    plansza[x, y] = "x";
                    x = x - 1;
                    if (x < 0 || x >= plansza.GetLength(0))
                    {
                        x = x + 1;
                    }
                    plansza[x, y] = player;
                }
                else if (klawisz.Key == ConsoleKey.D)

                {
                    plansza[x, y] = "x";
                    y = y + 1;
                    if (y < 0 || y >= plansza.GetLength(1))
                    {
                        y = y - 1;
                    }
                    plansza[x, y] = player;
                }

                else if (klawisz.Key == ConsoleKey.S)
                {
                    plansza[x, y] = "x";
                    x = x + 1;
                    if (x < 0 || x >= plansza.GetLength(1))
                    {
                        x = x - 1;
                    }
                    plansza[x, y] = player;
                }
                else if (klawisz.Key == ConsoleKey.A)

                {
                    plansza[x, y] = "x";
                    y = y - 1;
                    if (y < 0 || y >= plansza.GetLength(1))
                    {
                        y = y + 1;
                    }
                    plansza[x, y] = player;
                }


                Console.Clear();
                for (int i = 0; i < plansza.GetLength(0); i++)
                {
                    for (int j = 0; j < plansza.GetLength(1); j++)
                    {
                        Console.Write(plansza[i, j]);
                    }
                    Console.WriteLine("");
                }
            }






        }




    }
}



